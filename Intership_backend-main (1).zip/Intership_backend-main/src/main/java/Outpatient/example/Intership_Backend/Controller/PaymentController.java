package Outpatient.example.Intership_Backend.Controller;

public class PaymentController {
}
