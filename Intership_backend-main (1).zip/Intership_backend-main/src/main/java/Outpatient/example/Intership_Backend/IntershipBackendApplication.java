package Outpatient.example.Intership_Backend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class IntershipBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(IntershipBackendApplication.class, args);
	}

}
